package com.example.nguyenthicamnguyen_2328_gk;

import android.content.Intent;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.view.View;
import android.content.Intent;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SecondActivity extends AppCompatActivity {
    Button btnBack_328;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        btnBack_328 = findViewById(R.id.btnBack_328);
        btnBack_328.setOnClickListener(v->{
            Intent intent = new Intent(SecondActivity.this, SecondActivity.class);
            startActivity(intent);
            finish();
        });

    }
}